echo "running SARA simulation with CBR traffic and 4 simultanious data sessions"
ns manet.sara.CBR.tcl -rs 18
echo "running SARA simulation with FTP traffic and 4 simultanious data sessions"
ns manet.sara.FTP.tcl -rs 18
